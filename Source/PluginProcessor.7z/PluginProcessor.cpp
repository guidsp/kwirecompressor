/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin processor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
KwireAudioProcessor::KwireAudioProcessor()
#ifndef JucePlugin_PreferredChannelConfigurations
     : AudioProcessor (BusesProperties()
                     #if ! JucePlugin_IsMidiEffect
                      #if ! JucePlugin_IsSynth
                       .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                      #endif
                       .withOutput ("Output", juce::AudioChannelSet::stereo(), true)
                     #endif
                       ),
    parameters(*this, nullptr, "PARAMETERS", {  // Add parameters to the treestate
        std::make_unique<juce::AudioParameterFloat>(compGainID, compGainName, juce::NormalisableRange<float>(-24.f, 24.f, 0.1f), 0.0f),
        std::make_unique<juce::AudioParameterFloat>(compRatioID, compRatioName, juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 50.f),
        std::make_unique<juce::AudioParameterFloat>(compThresholdID, compThresholdName, juce::NormalisableRange<float>(-12.0f, 0.0f, 0.1f), -6.0f),
        std::make_unique<juce::AudioParameterFloat>(compAttackID, compAttackName, juce::NormalisableRange<float>(1.0f, 200.0f, 0.1f, 0.5f), 50.f),
        std::make_unique<juce::AudioParameterFloat>(compReleaseID, compReleaseName, juce::NormalisableRange<float>(1.0f, 800.f, 1.f, 0.5f), 100.f),
        std::make_unique<juce::AudioParameterFloat>(mixID, mixName, juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 100.f),
        std::make_unique<juce::AudioParameterFloat>(outGainID, outGainName, juce::NormalisableRange<float>(-12.f, 12.f, 0.1f), 0.0f)
                           }),
    oversampler(supportedChannels, osFactor, juce::dsp::Oversampling<float>::FilterType::filterHalfBandFIREquiripple, true, true)
#endif
{
}

KwireAudioProcessor::~KwireAudioProcessor()
{
}

//==============================================================================
const juce::String KwireAudioProcessor::getName() const
{
    return JucePlugin_Name;
}

bool KwireAudioProcessor::acceptsMidi() const
{
   #if JucePlugin_WantsMidiInput
    return true;
   #else
    return false;
   #endif
}

bool KwireAudioProcessor::producesMidi() const
{
   #if JucePlugin_ProducesMidiOutput
    return true;
   #else
    return false;
   #endif
}

bool KwireAudioProcessor::isMidiEffect() const
{
   #if JucePlugin_IsMidiEffect
    return true;
   #else
    return false;
   #endif
}

double KwireAudioProcessor::getTailLengthSeconds() const
{
    return 0.0;
}

int KwireAudioProcessor::getNumPrograms()
{
    return 1;   // NB: some hosts don't cope very well if you tell them there are 0 programs,
                // so this should be at least 1, even if you're not really implementing programs.
}

int KwireAudioProcessor::getCurrentProgram()
{
    return 0;
}

void KwireAudioProcessor::setCurrentProgram (int index)
{
}

const juce::String KwireAudioProcessor::getProgramName (int index)
{
    return {};
}

void KwireAudioProcessor::changeProgramName (int index, const juce::String& newName)
{
}

//==============================================================================
void KwireAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    compGain = *parameters.getRawParameterValue(compGainID);
    compRatio = *parameters.getRawParameterValue(compRatioID);
    compThreshold = *parameters.getRawParameterValue(compThresholdID);
    compAttack = *parameters.getRawParameterValue(compAttackID);
    compRelease = *parameters.getRawParameterValue(compReleaseID);

    compressor.setupParams(compRatio, compThreshold, compAttack, compRelease, sampleRate, supportedChannels);

    auto totalNumInputChannels = getTotalNumInputChannels();
    auto totalNumOutputChannels = getTotalNumOutputChannels();

    inAudio.resize(totalNumInputChannels);
    compAudio.resize(totalNumInputChannels);
    preCompAudio.resize(totalNumInputChannels);

    lastSamplingRate = sampleRate;

    juce::dsp::ProcessSpec spec; //set up DSP
    spec.sampleRate = sampleRate;
    spec.maximumBlockSize = samplesPerBlock;
    spec.numChannels = getTotalNumInputChannels();

    //set up oversampling
    oversamplerFilter.prepare(spec); //prepare the os filter
    oversamplerFilter.reset();

    oversampler.numChannels = getTotalNumInputChannels(); //set os numchannels
    oversampler.setUsingIntegerLatency(true);
    oversampler.clearOversamplingStages();

    oversampler.addOversamplingStage(juce::dsp::Oversampling<float>::FilterType::filterHalfBandFIREquiripple, 0.15f, -100.0f, 0.15f, -100.0f);

    oversampler.reset();
    oversampler.initProcessing(samplesPerBlock);

    setLatencySamples(oversampler.getLatencyInSamples());

    //set up the filter
    *oversamplerFilter.state = *juce::dsp::IIR::Coefficients<float>::makeLowPass(lastSamplingRate, 19000.0f, 0.71f);
}

void KwireAudioProcessor::releaseResources()
{
    // When playback stops, you can use this as an opportunity to free up any
    // spare memory, etc.
}

#ifndef JucePlugin_PreferredChannelConfigurations
bool KwireAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
  #if JucePlugin_IsMidiEffect
    juce::ignoreUnused (layouts);
    return true;
  #else
    // This is the place where you check if the layout is supported.
    // In this template code we only support mono or stereo.
    // Some plugin hosts, such as certain GarageBand versions, will only
    // load plugins that support stereo bus layouts.
    if (layouts.getMainOutputChannelSet() != juce::AudioChannelSet::mono()
     && layouts.getMainOutputChannelSet() != juce::AudioChannelSet::stereo())
        return false;

    // This checks if the input layout matches the output layout
   #if ! JucePlugin_IsSynth
    if (layouts.getMainOutputChannelSet() != layouts.getMainInputChannelSet())
        return false;
   #endif

    return true;
  #endif
}
#endif

void KwireAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages)
{
    juce::ScopedNoDenormals noDenormals;
    auto totalNumInputChannels  = getTotalNumInputChannels();
    auto totalNumOutputChannels = getTotalNumOutputChannels();

    for (int i = totalNumInputChannels; i < totalNumOutputChannels; ++i)
        buffer.clear (i, 0, buffer.getNumSamples());

    juce::dsp::AudioBlock<float> block(buffer); //point block to the buffer
    auto osBlock = oversampler.processSamplesUp(block); //make oversampled block

    //Make dry signal for mix
    dryBufferCh.clear();
    dryBuffer.clear();
    dryBufferCh.resize(buffer.getNumSamples(), 0.0f);
    dryBuffer.resize(buffer.getNumChannels(), dryBufferCh);

    for (int channel = 0; channel < totalNumInputChannels; ++channel)
    {
        auto dryData = buffer.getReadPointer(channel);

        for (int sample = 0; sample < buffer.getNumSamples(); ++sample)
        {
            dryBuffer[channel][sample] = dryData[sample];
        }
    }

    //send input to in meter
    for (int channel = 0; channel < totalNumInputChannels; ++channel)
        inAudio[channel] = buffer.getMagnitude(channel, 0, buffer.getNumSamples());
        //inAudio[channel] = buffer.getMagnitude(channel, 0, buffer.getNumSamples());

    //apply gain ramp to compressor gain
    inRamp.useGainRamp(buffer, compGain);

    //send amplified audio to comp ghost meter
    for (int channel = 0; channel < totalNumInputChannels; ++channel)
        preCompAudio[channel] = buffer.getMagnitude(channel, 0, buffer.getNumSamples());
        //preCompAudio[channel] = buffer.getMagnitude(channel, 0, buffer.getNumSamples());

    //update params
    compressor.updateParams(1.f + compRatio * 0.01f, 2.f * compThreshold, compAttack, compRelease);

    //overdrive
    compressor.overdrive(buffer);

    //compress
    compressor.compress(buffer);

    //overdrive
    compressor.overdrive(buffer);

    //send compressed audio to comp meter
    for (int channel = 0; channel < totalNumInputChannels; ++channel)
        compAudio[channel] = buffer.getMagnitude(channel, 0, buffer.getNumSamples());
        //compAudio[channel] = buffer.getMagnitude(channel, 0, buffer.getNumSamples());

    //Mix
    
    for (int channel = 0; channel < totalNumInputChannels; ++channel) 
    {
        auto channelData = buffer.getWritePointer(channel);
        auto scaledMix = mix * 0.01f;

        for (int sample = 0; sample < buffer.getNumSamples(); ++sample)
        {
            channelData[sample] = channelData[sample] * scaledMix + dryBuffer[channel][sample] * (1.0 - scaledMix);
        }
    }

    //filtering
    oversamplerFilter.process(juce::dsp::ProcessContextReplacing<float>(osBlock));

    //downsampling
    oversampler.processSamplesDown(block);

    //Out gain
    outRamp.useGainRamp(buffer, outGain);
}

//==============================================================================
bool KwireAudioProcessor::hasEditor() const
{
    return true; // (change this to false if you choose to not supply an editor)
}

juce::AudioProcessorEditor* KwireAudioProcessor::createEditor()
{
    return new KwireAudioProcessorEditor (*this);
}

//==============================================================================
void KwireAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    //storing parameters in memory
    auto state = parameters.copyState(); 
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void KwireAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    //retrieving the data from memory
    std::unique_ptr<juce::XmlElement> xmlState(getXmlFromBinary(data, sizeInBytes)); 

    if (xmlState.get() != nullptr)
        if (xmlState->hasTagName(parameters.state.getType()))
            parameters.replaceState(juce::ValueTree::fromXml(*xmlState));
}

//==============================================================================
// This creates new instances of the plugin..
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new KwireAudioProcessor();
}